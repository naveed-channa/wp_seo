const fs = require('fs');
wordpressSites = (count) =>{
    var data = fs.readFileSync('./wordpress/'+count+'.txt', 'utf8');
        let string = data.toString();
        let wp_sites = string.split("\n");
        let allSites = [];
        wp_sites.forEach(element => {
             allSites.push(element.trim());
        });
    return allSites;
}

const blogs  = ()  => {
    var fs = require('fs');
    try {  
        var data = fs.readFileSync('./dummyData/blogs.txt', 'utf8');
        let string = data.toString();
        return string.split("\n");   
    } catch(e) {
        console.log('Error:', e.stack);
    }

}
module.exports = {  
    blogs,
    wordpressSites
};