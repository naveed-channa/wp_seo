var WPAPI = require( 'wpapi' );
const WebsiteDummyData = require('../dummyData/websites');
const createLoader = require("node-console-loading");
async function post (req , res ,next){
    if(typeof req.body.count == 'undefined')
        req.body.count = 1
    
    let allSites = WebsiteDummyData.wordpressSites(req.body.count);
    console.time("TOTAL_TIME_IN_ONE_BLOG");
    for (let index = 1; index <= req.body.limit; index++) {
        let blogs = WebsiteDummyData.blogs();
        for (let b = 0; b < blogs.length; b++) {
            let blog = blogs[b];
            blog = blog.replace("\r" , "");
            console.log("BLOG--------------->" , blog);
            if(blog.trim())
            for (let index2 = 0; index2 < allSites.length; index2++) {
                try {
                    await sleep(process.env.TIME_INTERVAL);
                    const site = allSites[index2];
                    if(site){
                        let name = site+"/?rest_route=/";
                        let updatedData = await rep(req.body.content , req.body.replaceFrom , blog);
                        createLoader(wapiFunc(name , process.env.wp_username , process.env.wp_password , req.body.title , updatedData , blog , b), "SUCCESSFULLY_POST_DONE "+b+" :) "+ site, "Rejected! :( "+site );
                    }
                } catch (error) {
                    console.log("CATCH ERRPR" , error);
                    await sleep(process.env.TIME_INTERVAL_WP);
                }       
            }
        }
        await sleep(process.env.TIME_INTERVAL);
    }
    console.timeEnd("TOTAL_TIME_IN_ONE_BLOG");
    if( req.body.count < process.env.TOTAL_WORDPRESS_SITES_FILES_LIMIT){
        await sleep(process.env.TIME_INTERVAL_WP);
        req.body.count  = req.body.count + 1;
        await this.post(req , res , next);
    }
    //res.render('wordpress', { title: 'Successfully Post' });
    
    console.info("All Sites Posted Successfully Please check");
    return true;
    
};

async function rep(str,replaceWhat,replaceTo){
    var re = new RegExp(replaceWhat, 'g');
    return str.replace(re,replaceTo);
}

async function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

async function wapiFunc (endpoint , username , password , title , content , blog , count){
            try {
                //await sleep(process.env.TIME_INTERVAL);
                var wp = new WPAPI({
                    endpoint: endpoint,
                    username: username,
                    password: password
                });
                let pr = await wp.posts().create({
                    title: title,
                    content: content,
                    status: 'publish'
                })
                //console.info("SUCCESSFULLY_POST_DONE  "+count+" "  ,  endpoint.replace("/?rest_route=/" , ""));
                //await sleep(process.env.TIME_INTERVAL);
                // Loader.stop();
                return pr;
            } catch (error) {
                console.log("FOUND_ERROR_ON -<--------------------------------------------------------------------> " , endpoint);
                console.info("BLOG_NOT_SUBMITED_ON " , endpoint , "BLOG = " , blog);
                console.log("error" , error)
                await sleep(process.env.TIME_INTERVAL_WP);
            }
}

module.exports = {
    post
};